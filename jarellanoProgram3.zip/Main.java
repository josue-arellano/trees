/*
 *   Name:      Arellano, Josue
 *   File:      Main.java
 *   Project:   #1
 *   Due:       Feb 18, 2018
 *   Course:    cs14103-w18
 *
 *   Description:
 *              This
 */
package tree;

import java.util.Scanner;
import static tree.BinarySearchTreeMain.printError;
import static tree.BinarySearchTreeMain.printInorder;
import java.util.Random;

/**
 *
 * @author josue
 */
public class Main
{
    public static void main(String[] args)
    {
        final int SIZE = 100;
        Random rand = new Random();
        Integer[] nums = new Integer[SIZE];
        for (int i = 0; i < SIZE; i++)
        {
            int newNum = rand.nextInt(1000);
            while (contains(nums, i, newNum))
            {
                newNum = rand.nextInt(1000);
            }
            nums[i] = newNum;
        }

        Scanner kb = new Scanner(System.in);
        String input = "";
        BinarySearchTree<Integer> tree = new BinarySearchTree<Integer>(nums[0]);
        RedBlackTree<Integer> rbTree = new RedBlackTree<Integer>(nums[0]);
        for (Integer integer : nums)
        {
            rbTree.add(integer);
            tree.add(integer);
        }
        Scanner inputScan = new Scanner(input);
        boolean cont = true;
        do
        {
            printHelpMenu();
            input = "";
            char ans = 'H';
            while (input.length() == 0)
            {
                System.out.print("Command? ");
                input = kb.nextLine();
            }
            ans = input.charAt(0);
            ans = Character.toUpperCase(ans);
            Scanner cmnd = new Scanner(input);
            cmnd.next();
            Integer num = null;
            if (cmnd.hasNextInt())
            {
                num = cmnd.nextInt();
            }
            switch (ans)
            {
                case 'M':
                    printHelpMenu();
                    break;
                case 'I':
                    if (num != null)
                    {
                        Integer added = tree.add(num);
                        rbTree.add(num);
                        if (added != null)
                        {
                            System.out.println(added + " already exists, ignore.");
                        }
                    } else
                    {
                        printError(ans);
                    }
                    break;
                case 'D':
                    if (num != null)
                    {
                        Integer removed = tree.remove(num);
                        if (removed == null)
                        {
                            System.out.println(num + " doesn't exist!");
                        } else
                        {
                            printInorder(tree);
                        }
                    } else
                    {
                        printError(ans);
                    }
                    break;
                case 'L':
                    int bstLeaves = tree.getNumberOfLeaves();
                    int rbtLeaves = rbTree.getNumberOfLeaves();
                    System.out.println("Red-Black number of leaves: "
                            + rbtLeaves
                            + "\nBST number of leaves:       " 
                            + bstLeaves);
                    break;
                case 'R':
                    System.out.print("enter lower bound: ");
                    input = kb.nextLine();
                    cmnd = new Scanner(input);
                    Integer a = cmnd.nextInt();
                    System.out.print("enter upper bound: ");
                    input = kb.nextLine();
                    cmnd = new Scanner(input);
                    Integer b = cmnd.nextInt();
                    System.out.print("Red-Black Tree:     ");
                    rbTree.between(a, b);
                    System.out.print("\nBinary Search Tree: ");
                    tree.between(a, b);
                    System.out.println();
                    break;
                case 'E':
                    cont = false;
                    break;
                case 'H':
                    int rbHeight = rbTree.getHeight();
                    int treeHeight = tree.getHeight();
                    System.out.println("Red-Black height: " + rbHeight
                                       + "\nBST height:       " + treeHeight);
                    break;
                default:
                    System.out.println("Wrong input! Try one of these: ");
                    printHelpMenu();
                    break;
            }
        } while(cont);
        System.out.println("Thank you for using my program!");
    }

    public static boolean contains(Integer[] arr, int index, Integer val)
    {
        for(int i = 0; i < index + 1; i++)
        {
            if(val == arr[i])
                return true;
        }
        return false;
    }
    
    public static void printHelpMenu()
    {
        System.out.println("  I  Insert a value\n"
                + "  D  Delete a value\n"
                + "  L  Number of leaves\n"
                + "  R  Range\n"
                + "  H  Height\n"
                + "  E  Exit the program\n"
                + "  M  Display this message");
    }
}
